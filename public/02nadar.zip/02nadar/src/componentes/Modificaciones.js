import React from 'react';

function Modificaciones() {
  return (
    



<div>
      <h1>Descarga de Documentos</h1>
      <a href="/modificaciones.pdf" target="_blank" rel="noopener noreferrer">
        Descargar Documento PDF
      </a>
      <p>
        También puedes enlazar a una imagen (si está en public/imagen.jpg):
        <a href="/imagen.jpg" target="_blank" rel="noopener noreferrer">
          Ver Imagen
        </a>
      </p>
    </div>







  ) 
}



export default Modificaciones;