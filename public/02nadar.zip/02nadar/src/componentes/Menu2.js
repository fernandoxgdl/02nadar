import React from 'react';

function Menu2() {
  return (
    <nav className='menu2'>
      <ul>
        <li><a href="https://www.w3schools.com/" target="_blank">A Ñ A D I R</a></li>
        <li><a href="https://www.w3schools.com/"target="_blank">C O M P R A R</a></li>
      </ul>
    </nav>

  )
}

export default Menu2;