import React from 'react'

export default function Todo1() {
  return (
    <div className='todo' >
     
        <div className='items'>


        <div class="item1">
        </div>

        <div class="item2"></div>

        <div class="item3"></div>

        <div class="item4"></div>

        <div class="item5"></div>

        <div class="item6"></div>

        <div class="item7"></div>


        </div>

    </div>
  )
}
