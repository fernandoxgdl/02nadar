import './App.css';
import Todo1 from './componentes/Todo1';
import Todo2 from './componentes/Todo2';
import Menu2 from './componentes/Menu2';
import Menupri from './componentes/Menupri';

function App() {
  return (

    <div className="App">
      <h1>  </h1>

      <Todo2></Todo2>
      <Menu2></Menu2>
      <Menupri></Menupri>
<div className='cuerpo'> 
<Todo1></Todo1>

</div>


    </div>
    
  );
}
export default App;
